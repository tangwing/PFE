/********************************************************************************
***** This is a sample program to illustrate how using version 1 of the   *******
***** PREMIP library.                                                     *******
***** This library enables C++ developpers who work with IBM Concert      *******
***** technology to preprocess automatically their MIP formulation before *******
***** it is solved by IBM Cplex solver.                                   *******
*********************************************************************************
***** Authors: V. T'kindt, L. Zinan, T. Noguer.                           *******
***** Version: 1.0        Date: 10/9/2013                                 *******
***** Note: this version of PREMIP works only with single dimension       *******
*****       variables and minimization problems. Preprocessing is done    *******
*****       on boolean variables.                                         *******
*********************************************************************************
***** Copyright: University Fran�ois Rabelais of Tours, France            *******
***** This code can be used and modified freely while it is not for       *******
***** commercial use.                                                     *******
*******************************************************************************/

This code has been created from a more complete program using the PREMIP library. It compiles but
is not guaranteed from being without any bugs If some are fixed, new releases will be delivered.