/********************************************************************************
***** This is a sample program to illustrate how using version 1 of the   *******
***** PREMIP library.                                                     *******
***** This library enables C++ developpers who work with IBM Concert      *******
***** technology to preprocess automatically their MIP formulation before *******
***** it is solved by IBM Cplex solver.                                   *******
*********************************************************************************
***** Authors: V. T'kindt, L. Zinan, T. Noguer.                           *******
***** Version: 1.0        Date: 10/9/2013                                 *******
***** Note: this version of PREMIP works only with single dimension       *******
*****       variables and minimization problems. Preprocessing is done    *******
*****       on boolean variables.                                         *******
*********************************************************************************
***** Copyright: University Fran�ois Rabelais of Tours, France            *******
***** This code can be used and modified freely while it is not for       *******
***** commercial use.                                                     *******
*******************************************************************************/

#include <time.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <cmath>
#include <ctime>

#include "Preprocessing.h"
#include "Cexception.h"
#include <ilcplex/ilocplex.h>

#define MIP_ALONE 0
// If set to 0, preprocessing is performed before the reduced MIP is solved
// If set to 1, no preprocessing is performed and the original MIP is solved

#define DEBUG false
// If set to false, no debugging information is output by the library
// If set to true, debugging information are output by the library

using namespace std;

ILOSTLBEGIN

Preprocessing *prepro;
int nbFix=0, nbBool=0, nbNodes=0, nbJobs, UB;
double objValue=0, temps_cpu=0, temps_cpu_pre=0;
bool opti=false;

double diffclock(clock_t clock1,clock_t clock2)
{
	double diffticks=clock1-clock2;
	double diffs=diffticks/CLOCKS_PER_SEC;
	return diffs;
}

/*************************************************************************************
***** Function: PreprocessAndSolve                                               *****
**************************************************************************************
***** This function implements the way to use PREMIP library                     *****
***** Inputs:                                                                    *****
*****    head: an array containing the indices of the boolean variables in pvar  *****
*****                    that have to be preprocessed                            *****
*****    nbBool: the number of boolean variables to preprocess                   *****
*****    penv, pcplex, pmodel, pvar,pcon : pointers to the CPLEX data structures *****
*****                    (environment, cplex, model, variables,constraints)      *****
*****                    containing the LP relaxation of the IP.                 *****
*************************************************************************************/

void PreprocessAndSolve(int *head, int nbBool, IloEnv *penv, IloCplex *pcplex, IloModel *pmodel, IloNumVarArray *pvar,IloRangeArray *pcon)
{
	bool noMIP=false;
	clock_t temp1,temp2,tempPre1,tempPre2;

	nbFix=0;
	nbNodes=0;
	prepro=new Preprocessing();

	// Set the indices of variables to be considered for preprocessing
	prepro->PRESetHead(head);
	// Set if debugging information must be ouptput
	prepro->PRESetDebug(DEBUG);
	// The pseudocosts must not be computed by means of Tomlin's penalities (unstable method)
	prepro->PRESetTomlin(false);
	// Set the Upper bound required for preprocessing
	prepro->PRESetUB(UB);		

	nbFix=0;

	// CASE 1: No preprocessing is required before solving the IP model
	if(MIP_ALONE==1)
	{ 
		temp1 = clock();

		// Step 1: give the LP relaxation to the library
		prepro->PREInitializeLP(penv, pcplex, pmodel, pvar, pcon);
		// Step 2: convert the LP model into an IP model (real valued variables are turned into integer valued variables) 
		prepro->PREInitializeMIPfromLP(penv , pcplex , pmodel , pvar, pcon,head);
		// Step 3: solve the IP formulation
		prepro->PRESolveMIP();

		objValue = prepro->PREGetMipOpt();
		nbNodes = prepro->PREGetMIPNbNode();
		temp2 = clock();
		if (DEBUG)
			cout<<"Optimal solution found: "<<prepro->PREGetMipOpt()<<endl; 
		temps_cpu=diffclock(temp2,temp1);

		if(DEBUG) {
				ofstream logs("logs/LOGS.txt", ios::app);
				if(prepro->PREisMIPOpt())
					logs << "OPTIMAL" << endl;
				else
					logs << "NOT_OPTIMAL" << endl;
				logs<<"Optimal value: "<<objValue<<endl;
				logs<<"CPU time: "<<temps_cpu<<endl;
				logs<<"Nb Nodes: "<<nbNodes<<endl<<endl;
				logs.close();
		}

		ofstream outFile("MIP.txt");
		if(prepro->PREisMIPOpt())
			outFile << "OPTIMAL" << endl;
		else
			outFile << "NOT_OPTIMAL" << endl;
		outFile << nbJobs << endl;
		outFile << objValue << endl;
		outFile << temps_cpu << endl;
		outFile << nbNodes << endl;
		outFile.close();
	} // END CASE 1

	// CASE 2: Preprocessing is requested before MIP is solved
	if(MIP_ALONE==0)
	{ 
		if(DEBUG)
			pcplex->exportModel("model.lp");	

		tempPre1=clock();
		cout << "Preprocessing the model...\n";
		// Step 1: give the LP relaxation to the library
		prepro->PREInitializeLP(penv, pcplex, pmodel, pvar, pcon);
		// Step 2: solves the LP relaxation
		prepro->PRESolveLP();
		// Step 3: preprocess by using the LP relaxation
		prepro->PREPreprocessing();
		
		// Step 4: analyse the situation after preprocessing
		nbFix += prepro->PREGetNbFix();
		if(prepro->PREIsOptiNoPRE() || nbFix == nbBool) // If no preprocessing (i.e. LB=UB before prepro)
		{
			objValue=(double)UB;
			noMIP = true;
			tempPre2  = clock();
			temps_cpu_pre+=diffclock(tempPre2,tempPre1);
			if(prepro->PREIsOptiNoPRE())
				cout << "UB=LB!" << " " << UB << " " << prepro->PREGetLpOpt() << endl;
			else if(nbFix == nbBool)
				cout << "IS INTEGRAL!"<<endl;
		}
		
		// Step 5: solve the reduced IP formulation
		if (!noMIP)
		{
		 tempPre2=clock();
		 temps_cpu_pre += diffclock(tempPre2, tempPre1);
		 cout << "NbFix " << nbFix << " on " << nbBool << " variables" <<endl;

		 // Step 5.1: convert the LP model into an IP model (real valued variables are turned into integer valued variables) 
		 prepro->PREInitializeMIPfromLP(penv , pcplex , pmodel , pvar, pcon,head);
		 // Step 5.2: clear data structures of cplex
		 pcplex->extract(*pmodel);
		 // Step 5.3: fix variables to the IP formulation, as deduced during the preprocessing phase (normally useless, since we convert reduced LP model)
		 prepro->PREFixVarToMIP();
		 // Step 5.4: solve the reduced IP formulation
		 prepro->PRESolveMIP();

		 // Step 5.5: retrieving information from the solution
		 objValue=prepro->PREGetMipOpt();
		 nbNodes = prepro->PREGetMIPNbNode();
		 opti = prepro->PREisMIPOpt();
		 temps_cpu=temps_cpu_pre+diffclock(clock(),tempPre2);
		 if(DEBUG)
				cout << "--------------------------" << endl;
		}

	    // Step 6: output the results
		ofstream outFile("PreMIP.txt");
		if (prepro->PREIsOptiNoPRE() && nbFix == 0)
					outFile << "NO_PRE" << endl;
			else
					outFile << "PRE" << endl;
		if(prepro->PREisMIPOpt())
			outFile << "OPTIMAL" << endl;
		else
			outFile << "NOT_OPTIMAL" << endl;
		outFile << nbJobs << endl;
		outFile << objValue << endl;
		outFile << temps_cpu << endl; // CPU time for the whole solution process
		outFile << temps_cpu_pre << endl; // CPU time of the preprocessing
		outFile << nbNodes << endl;
		if (nbBool>0) // Percentage of fixed variables
				outFile << 100.0*double(nbFix)/double(nbBool) << endl;
			else 
				outFile << 0 << endl;
		outFile.close();
	}

	// Delete the preprocessing object
	try {
		delete prepro;
	}
	catch(...) {
		cerr << "Error while deleting prepro!" << endl;
	}
}




int main(int argc)
{
 IloEnv env;
 IloModel model(env);
 IloNumVarArray var(env);
 IloRangeArray con(env);

 int *head;

 // Step 1: read the instance from your data file
 // INSERT CODE HERE

 // Step 2: create your model, the LP relaxation of your IP.
 // Note: var must contain all variables. Boolean variables in the original IP are now real variables in [0;1]
 //       con must contain all constraints of the model. 
 // INSERT CODE HERE

 // Step 3: create the array "head". It is the list of boolean variables in the original IP which have to be processed.
 nbBool=0;
 head = new int[var.getSize()];
 for(int i=0;i<var.getSize();i++)
	{
	 // MODIFY THE LINE BELOW TO FIT WITH YOUR MODEL
	 /* if ( var[i] is the relaxed variable associated to a boolean variable in the original IP)*/
		if (true)
				{
					head[nbBool]=var[i].getId();
					nbBool++;
				}
				else
					head[i]=-1;
	}

 // Step 4: Create the cplex object and associate it the model
 IloCplex cplex(model);

 // Step 5: Compute the Upper Bound required to run preprocessing
 UB=999999; // Note: 999999 is a default value, replace it!

 // Step 6: Run the library to solve your problem
 try{
  PreprocessAndSolve(head,nbBool, &env, &cplex , &model , &var, &con);
 }
 catch (IloException& e) {
			cerr << "Concert exception caught: " << e << endl;
			getch();
		}
 catch (int e) {
			cerr << "Known exception caught : " << e << endl;
			getch();
		}
 catch(...) {
			cerr << "Unknown exception caught " << MIP_ALONE << endl;
			getch();
		}
}
